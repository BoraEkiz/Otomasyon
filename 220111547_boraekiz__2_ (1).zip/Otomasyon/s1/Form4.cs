﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace s1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double boy, kilo;

            kilo = Convert.ToDouble(kkilo.Text);
            boy = Convert.ToDouble(kkiloo.Text);

            double kboy = boy / 100;
            double sonuc = (kilo / (kboy * kboy));
            label4.Text = Convert.ToString(sonuc);
            if (sonuc<18.5)
            {
                label5.Text = "Zayıf";
            }
            if (sonuc > 18.5 && sonuc<25)
            {
                label5.Text = "Normal";
            }
            if (sonuc > 25 && sonuc < 30)
            {
                label5.Text = "Fazla Kilolu";
            }
            if (sonuc > 30 && sonuc < 40)
            {
                label5.Text = "Obez";
            }
            if (sonuc > 40)
            {
                label5.Text = "Aşırı Obez";
            }


        }

        private void tmz_Click(object sender, EventArgs e)
        {
            
            label4.Text = "";
            label5.Text = "";
            kkilo.Clear();
            kkiloo.Clear();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
