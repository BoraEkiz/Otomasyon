﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace s1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

      

        

      

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ad = textBox1.Text;
            string soyad = textBox2.Text;
            string yas = textBox3.Text;
            string kilo = textBox4.Text;
            string boy = textBox5.Text;

            // Alınan veriyi MessageBox içinde göster
            string mesaj = $"Ad: {ad}\nSoyad: {soyad}\nYaş: {yas} \n Kilo: {kilo}\n Boy: {boy}" ;
            MessageBox.Show(mesaj, "Kayıt Bilgileri", MessageBoxButtons.OK, MessageBoxIcon.Information);



        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tmz_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();


        }

    }
}
